package client;

import java.io.BufferedReader;
import java.io.IOException;

/**
 *
 * @author Dejan Pejić
 */
public class ReceiveMessageFromServer implements Runnable
{
    Client parent;
    BufferedReader br;
    
    private int clientStatus;
    
    public ReceiveMessageFromServer(Client parent) 
    {
        this.parent = parent;
        this.br = parent.getBr();
        this.clientStatus = 0;
    }
    
    @Override 
    public void run()
    {
        while (true)
        {
            String serverMessage;
            switch (clientStatus)
            {
                case 0:
                    try
                    {
                        serverMessage = this.br.readLine();
                        if (serverMessage.equals("Correct!"))
                        {
                            parent.loginSuccessful(true);
                            serverMessage = "";
                            while(serverMessage.equals(""))
                                serverMessage = this.br.readLine();
                            String[] serverInfo = serverMessage.split(":");
                            String[] comboInfo = new String[serverInfo.length - 1];
                            for (int i = 0; i < comboInfo.length; i++)
                                comboInfo[i] = serverInfo[i + 1];
                            if (parent.getRole().equals("admin"))
                                parent.updateContestants(comboInfo);
                            
                            serverMessage = "";
                            while(serverMessage.equals(""))
                                serverMessage = this.br.readLine();
                            
                            serverInfo = serverMessage.split(":");
                            comboInfo = new String[serverInfo.length - 1];
                            for (int i = 0; i < comboInfo.length; i++)
                                comboInfo[i] = serverInfo[i + 1];
                            if (parent.getRole().equals("admin"))
                                parent.updateAdmins(comboInfo);
                            
                            serverMessage = "";
                            while(serverMessage.equals(""))
                                serverMessage = this.br.readLine();
                            
                            serverInfo = serverMessage.split(":");
                            comboInfo = new String[serverInfo.length - 1];
                            for (int i = 0; i < comboInfo.length; i++)
                                comboInfo[i] = serverInfo[i + 1];
                            if (parent.getRole().equals("admin"))
                                parent.updateSets(comboInfo);
                            
                            serverMessage = "";
                            while(serverMessage.equals(""))
                                serverMessage = this.br.readLine();
                            
                            parent.writeActiveSet(serverMessage);
                            
                            if (parent.getRole().equals("admin"))
                                clientStatus = 1;
                            else
                                clientStatus = 2;
                            
                        }
                        else
                        {
                            parent.loginSuccessful(false);
                        }
                    }
                    catch (IOException ex) 
                    {
                        System.out.println("Server nije dostupan!");
                        parent.printMess("Diskonektovan sa servera!");
                        parent.logout();
                        return;
                    }
                    break;
                case 1:
                    try 
                    {
                        serverMessage = this.br.readLine();
                        if (serverMessage.equals("To korisnicko ime vec postoji!"))
                            parent.printMess(serverMessage);
                        else if (serverMessage.startsWith("New contestant") || serverMessage.startsWith("Contestant ejected"))
                        {
                            String[] serverInfo = serverMessage.split(":");
                            String[] comboInfo = new String[serverInfo.length - 1];
                            for (int i = 0; i < comboInfo.length; i++)
                                comboInfo[i] = serverInfo[i + 1];
                            parent.updateContestants(comboInfo);
                        }
                        else if (serverMessage.startsWith("New admin") || serverMessage.startsWith("Admin ejected"))
                        {
                            String[] serverInfo = serverMessage.split(":");
                            String[] comboInfo = new String[serverInfo.length - 1];
                            for (int i = 0; i < comboInfo.length; i++)
                                comboInfo[i] = serverInfo[i + 1];
                            parent.updateAdmins(comboInfo);
                        }
                        else if (serverMessage.startsWith("Active set"))
                        {
                            String[] serverInfo = serverMessage.split(":");
                            parent.writeActiveSet(serverInfo[1]);
                            System.out.println("KLIJENT: Aktiviran " + serverInfo[1]);
                        }
                        else if (serverMessage.equals("AdminAdio!"))
                        {
                            System.out.println(parent.getUsername() + " je izbacen!");
                            parent.logout();
                        }
                        else if (serverMessage.equals("Ne mozete izbaciti sami sebe!"))
                            parent.printMess(serverMessage);
                    }
                    catch (IOException ex) 
                    {
                        System.out.println("Server nije dostupan.");
                        parent.printMess("Diskonektovan sa servera!");
                        parent.logout();
                        return;
                    }
                    break;
                case 2:
                    try 
                    {
                        serverMessage = this.br.readLine();
                        if (serverMessage.equals("Vec ste zavrsili sa ovim setom pitanja!"))
                            parent.printMess(serverMessage);
                        else if (serverMessage.startsWith("Let's go"))
                            parent.readyWindow(serverMessage);
                        else if (serverMessage.startsWith("Active set"))
                        {
                            String[] serverInfo = serverMessage.split(":");
                            parent.writeActiveSet(serverInfo[1]);
                        }
                        else if (serverMessage.startsWith("Question:"))
                            parent.updateQuestionWindow(serverMessage);
                        else if (serverMessage.startsWith("SetEnd!"))
                            parent.closeQuestionWindow();
                        else if (serverMessage.startsWith("Results"))
                            parent.updateTable(serverMessage);
                        else if (serverMessage.startsWith("Eject answers"))
                            parent.ejectAnswers(serverMessage);
                        else if (serverMessage.equals("Vec ste iskoristili tu pomoc!"))
                            parent.printMess(serverMessage);
                        else if (serverMessage.equals("ChangedQuestion"))
                            parent.QuestionChange();
                        else if (serverMessage.startsWith("HelpNotSuccessful"))
                        {
                            String[] serverInfo = serverMessage.split(":");
                            parent.printMess(serverInfo[1]);
                        }
                        else if (serverMessage.startsWith("AvailableContestants"))
                        {
                            String[] serverInfo = serverMessage.split(":");
                            String[] comboInfo = new String[serverInfo.length - 1];
                            for (int i = 0; i < comboInfo.length; i++)
                                comboInfo[i] = serverInfo[i + 1];
                            parent.availableContestantsSetup(comboInfo);
                        }
                        else if (serverMessage.startsWith("ContestantNeedsHelp"))
                        {
                            String[] serverInfo = serverMessage.split(":");
                            parent.helpWindowSetup(serverInfo[1]);
                        }
                        else if (serverMessage.startsWith("FriendQuestion:"))
                            parent.updateHelpWindow(serverMessage);
                        else if (serverMessage.startsWith("FriendEjectAnswers"))
                            parent.ejectFriendAnswers(serverMessage);
                        else if (serverMessage.startsWith("FriendSentHelp"))
                            parent.showHelp(serverMessage);
                        else if (serverMessage.equals("FriendAsked"))
                            parent.friendAsked();
                        else if (serverMessage.equals("ContestantAdio!"))
                        {
                            System.out.println(parent.getUsername() + " je izbacen!");
                            parent.logout();
                        }
                            
                    }
                    catch (IOException ex) 
                    {
                        System.out.println("Server nije dostupan.");
                        parent.printMess("Diskonektovan sa servera!");
                        parent.logout();
                        return;
                    }
                    break;
                default:
                    break;
            }
        }
    }
}