package server;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Dejan Pejić
 */
public class ContestantSetSuccess implements Serializable
{
    private Set set;
    private int totalAnswers;
    private int correctAnswers;
    private boolean rejected;
    private boolean fiftyFifty;
    private boolean changeQuestion;
    private boolean friendHelp;
    private int changedQuestion;
    private ArrayList<Integer> ejectedQuestions;
    
    public ContestantSetSuccess(Set set)
    {
        this.set = set;
        this.totalAnswers = 0;
        this.correctAnswers = 0;
        this.rejected = false;
        this.fiftyFifty = true;
        this.changeQuestion = true;
        this.friendHelp = true;
        this.changedQuestion = 0;
        this.ejectedQuestions = new ArrayList<>();
    }
    
    public Set getSet()
    {
        return set;
    }
    
    public void setSet(Set set)
    {
        this.set = set;
    }
    
    public int getTotalAnswers()
    {
        return totalAnswers;
    }
    
    public void setTotalAnswers(int correctAnswers)
    {
        this.totalAnswers = correctAnswers;
    }
    
    public void addTotalAnswers()
    {
        totalAnswers++;
    }
    
    public int getCorrectAnswers()
    {
        return correctAnswers;
    }
    
    public void setCorrectAnswers(int correctAnswers)
    {
        this.correctAnswers = correctAnswers;
    }
    
    public void addCorrectAnswers()
    {
        correctAnswers++;
    }
    
    public boolean getFiftyFifty()
    {
        return fiftyFifty;
    }
    
    public void setFiftyFifty(boolean fiftyFifty)
    {
        this.fiftyFifty = fiftyFifty;
    }
    
    public boolean getChangeQuestion()
    {
        return changeQuestion;
    }
    
    public void setChangeQuestion(boolean changeQuestion)
    {
        this.changeQuestion = changeQuestion;
    }
    
    public boolean getFriendHelp()
    {
        return friendHelp;
    }
    
    public void setFriendHelp(boolean friendHelp)
    {
        this.friendHelp = friendHelp;
    }
    
    public boolean getRejected()
    {
        return rejected;
    }
    
    public void setRejected(boolean rejected)
    {
        this.rejected = rejected;
    }
    
    public void setChangedQuestion(int changedQuestion)
    {
        this.changedQuestion = changedQuestion;
    }
    
    public int getChangedQuestion()
    {
        return changedQuestion;
    }
    
    public void addEjectedQuestions(int number)
    {
        this.ejectedQuestions.add(number);
    }
    
    public ArrayList<Integer> getEjectedQuestions()
    {
        return ejectedQuestions;
    }
}