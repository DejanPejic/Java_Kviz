package server;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Dejan Pejic
 */
public class Set implements Serializable
{
    private String setName;
    private ArrayList<Question> questions = new ArrayList();

    public String getSetName() 
    {
        return setName;
    }
    
    public void setSetName(String setName)
    {
        this.setName = setName;
    }

    public ArrayList<Question> getQuestions() 
    {
        return questions;
    }
    
    public void setQuestions(ArrayList<Question> questions)
    {
        this.questions = questions;
    }
    
    public void addQuestion(Question question) 
    {
        this.questions.add(question);
    }
}