
package server;

import java.io.FileOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

/**
 *
 * @author Dejan Pejić
 */
public class ConnectedQuizClient implements Runnable 
{
    private Socket socket;
    private String userName;
    private String password;
    private String role;
    private BufferedReader br;
    private PrintWriter pw;
    private ArrayList<ConnectedQuizClient> allClients;
    private ArrayList<Contestant> contestants;
    private ArrayList<Set> sets;
    private ArrayList<String> admins;
    private QuizServer parent;
    private int clientStatus;
    private SecretKey symmetricKey;
    private byte[] initializationVector;
    
    private String usersTxt = "C:\\Users\\Korisnik\\Desktop\\Java-zadatak2\\users.txt";
    private static final String AES_CIPHER_ALGORITHM = "AES/CBC/PKCS5PADDING";
    
    public String getUserName() 
    {
        return userName;
    }

    public void setUserName(String userName) 
    {
        this.userName = userName;
    }

    public String getPassword() 
    {
        return password;
    }

    public void setPassword(String password) 
    {
        this.password = password;
    }
    
    public String getRole() 
    {
        return role;
    }

    public void setRole(String role) 
    {
        this.role = role;
    }
    
    public void setClientStatus(int status)
    {
        this.clientStatus = status;
    }
    
    public int getClientStatus()
    {
        return clientStatus;
    }
    
    public ConnectedQuizClient(Socket socket, ArrayList<ConnectedQuizClient> allClients, ArrayList<Contestant> contestants, ArrayList<Set> sets, ArrayList<String> admins, QuizServer server, SecretKey symmetricKey, byte[] initializationVector) throws Exception
    {
        this.socket = socket;
        this.allClients = allClients;
        this.contestants = contestants;
        this.sets = sets;
        this.admins = admins;
        this.parent = server;
        this.symmetricKey = symmetricKey;
        this.initializationVector = initializationVector;

        try 
        {
            this.br = new BufferedReader(new InputStreamReader(this.socket.getInputStream(), "UTF-8"));
            this.pw = new PrintWriter(new OutputStreamWriter(this.socket.getOutputStream()), true);
            
            this.userName = "";
            this.password = "";
            this.role = "";
            this.clientStatus = 0;
        } catch (IOException ex) {
            Logger.getLogger(ConnectedQuizClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        
    @Override
    public void run() 
    {
        while (true)
        {
            switch (clientStatus)
            {
                case 0:
                    try
                    {
                        String userData = this.br.readLine();
                        String[] splitedUserData = userData.split(":");
                        if (splitedUserData.length != 3)
                        {
                            System.out.println("Korisnikovi podaci nisu u odgovarajucem obliku!");
                            System.exit(0);
                        }
                        else
                        {
                            ByteArrayOutputStream bytesArray = new ByteArrayOutputStream();
                            try (FileInputStream readFile = new FileInputStream(usersTxt)) 
                            {
                                byte[] buffer = new byte[1024];
                                int bytesRead;
                                while ((bytesRead = readFile.read(buffer)) != -1) 
                                    bytesArray.write(buffer, 0, bytesRead);
                            } catch (IOException e) {
                                System.out.println("Greska prilikom citanja fajla users.txt!");
                            }
                            byte[] encryptedUsers = bytesArray.toByteArray();

                            String decryptedUsers = do_AESDecryption(encryptedUsers, symmetricKey, initializationVector);
                            
                            String[] splitedUsers = decryptedUsers.split("\n");
                            
                            for (String str: splitedUsers)
                            {
                                String[] txtUserData = str.split(":");
                                if (txtUserData.length != 3)
                                {
                                    System.out.println("Korisnikovi podaci iz fajla nisu u odgovarajucem obliku!");
                                    System.exit(0);
                                }
                                if (userData.equals(str))
                                {
                                    if (splitedUserData[2].equals("admin"))
                                    {
                                        clientStatus = 1;
                                        System.out.println("[admin]: " + splitedUserData[0] + " se ulogovao!");
                                    }
                                    else if (splitedUserData[2].equals("contestant"))
                                    {
                                        clientStatus = 2;
                                        System.out.println("[takmicar]: " + splitedUserData[0] + " se ulogovao!");
                                    }
                                    else
                                    {
                                        System.out.println("Nepostojeci korisnik!");
                                        System.exit(0);
                                    }
                                    
                                    this.pw.println("Correct!");
                                    
                                    this.userName = splitedUserData[0];
                                    this.password = splitedUserData[1];
                                    this.role = splitedUserData[2];
                                    
                                    if (this.role.equals("contestant"))
                                    {
                                        for(Contestant cnt: this.contestants)
                                        {
                                            if (cnt.getUserName().equals(this.userName))
                                            {
                                                cnt.setAvailable(true);
                                                break;
                                            }
                                        }
                                    }
                                    
                                    String existingContestants = "Contestants";
                                    for (Contestant cont: this.contestants)
                                        existingContestants += ":" + cont.getUserName();
                                    this.pw.println(existingContestants);
                                    
                                    String existingAdmins = "Admins";
                                    for (String adm: this.admins)
                                        existingAdmins += ":" + adm;
                                    this.pw.println(existingAdmins);
                                    
                                    String existingSets = "Sets";
                                    for (Set set: this.sets)
                                        existingSets += ":" + set.getSetName();
                                    this.pw.println(existingSets);
                                    
                                    this.pw.println(parent.getActiveSet().getSetName());
                                    
                                    break;
                                }
                            }
                            
                            if (clientStatus == 0)
                            {
                                this.pw.println("Not correct!");
                            }
                        }
                    } catch (IOException ex) {
                        System.out.println("Korisnik je diskonektovan!");
                        return;
                    } catch (Exception ex) {
                        Logger.getLogger(ConnectedQuizClient.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    break;

                case 1:
                    try
                    {
                        String clientMess = this.br.readLine();
                        if (clientMess.startsWith("New contestant"))
                        {
                            boolean exist = false;
                            String[] newContestantInfo = clientMess.split(":");
                            
                            ByteArrayOutputStream bytesArray = new ByteArrayOutputStream();
                            try (FileInputStream readFile = new FileInputStream(usersTxt)) 
                            {
                                byte[] buffer = new byte[1024];
                                int bytesRead;
                                while ((bytesRead = readFile.read(buffer)) != -1) 
                                    bytesArray.write(buffer, 0, bytesRead);
                            } catch (IOException e) {
                                System.out.println("Greska prilikom citanja fajla users.txt!");
                            }
                            byte[] encryptedUsers = bytesArray.toByteArray();

                            String decryptedUsers = do_AESDecryption(encryptedUsers, symmetricKey, initializationVector);
                            
                            String[] splitedUsers = decryptedUsers.split("\n");
                            for (String str: splitedUsers)
                            {
                                String[] cntInfo = str.split(":");
                                if (newContestantInfo[1].equals(cntInfo[0]))
                                {
                                    exist = true;
                                    break;
                                }
                            }
                            
                            if (exist)
                            {
                                this.pw.println("To korisnicko ime vec postoji!");
                                //System.out.println("To korisnicko ime vec postoji!");
                            }
                            else
                            {
                                Contestant cont = new Contestant(newContestantInfo[1]);
                                contestants.add(cont);
                                String contestantList = "New contestant";
                                
                                for (Contestant cnt: this.contestants)
                                    contestantList += ":" + cnt.getUserName();
                                
                                for (ConnectedQuizClient client: allClients)
                                    client.pw.println(contestantList);
                                
                                System.out.println(contestantList);
                                
                                String newContestant = newContestantInfo[1] + ":" + newContestantInfo[2] + ":" + "contestant\n";
                                decryptedUsers += newContestant;
                                encryptedUsers = do_AESEncryption(decryptedUsers, symmetricKey, initializationVector);
                                
                                try (FileOutputStream writer = new FileOutputStream(usersTxt)) 
                                {
                                    writer.write(encryptedUsers);
                                } catch (IOException e) {
                                    System.out.println("Greska prilikom upisivanja u fajl users.txt!");
                                }
                            }
                        }
                        else if (clientMess.startsWith("New admin"))
                        {
                            boolean exist = false;
                            String[] newAdminInfo = clientMess.split(":");
                            
                            ByteArrayOutputStream bytesArray = new ByteArrayOutputStream();
                            try (FileInputStream readFile = new FileInputStream(usersTxt)) 
                            {
                                byte[] buffer = new byte[1024];
                                int bytesRead;
                                while ((bytesRead = readFile.read(buffer)) != -1) 
                                    bytesArray.write(buffer, 0, bytesRead);
                            } catch (IOException e) {
                                System.out.println("Greska prilikom citanja fajla users.txt!");
                            }
                            byte[] encryptedUsers = bytesArray.toByteArray();

                            String decryptedUsers = do_AESDecryption(encryptedUsers, symmetricKey, initializationVector);
                            
                            String[] splitedUsers = decryptedUsers.split("\n");
                            for (String str: splitedUsers)
                            {
                                String[] admInfo = str.split(":");
                                if (newAdminInfo[1].equals(admInfo[0]))
                                {
                                    exist = true;
                                    break;
                                }
                            }
                            
                            if (exist)
                            {
                                this.pw.println("To korisnicko ime vec postoji!");
                            }
                            else
                            {
                                admins.add(newAdminInfo[1]);
                                String adminList = "New admin";
                                
                                for (String str: this.admins)
                                    adminList += ":" + str;
                                
                                for (ConnectedQuizClient client: allClients)
                                    client.pw.println(adminList);
                                
                                String newAdmin = newAdminInfo[1] + ":" + newAdminInfo[2] + ":" + "admin\n";
                                decryptedUsers += newAdmin;
                                encryptedUsers = do_AESEncryption(decryptedUsers, symmetricKey, initializationVector);
                                
                                try (FileOutputStream writer = new FileOutputStream(usersTxt)) 
                                {
                                    writer.write(encryptedUsers);
                                } catch (IOException e) {
                                    System.out.println("Greska prilikom upisivanja u fajl users.txt!");
                                }
                            }
                        }
                        else if (clientMess.startsWith("Activate set"))
                        {
                            String[] activateSetInfo = clientMess.split(":");
                            
                            for (Set set: this.sets)
                            {
                                if (activateSetInfo[1].equals(set.getSetName()))
                                {
                                    parent.setActiveSet(set);
                                    String activatedSet = "Active set:" + parent.getActiveSet().getSetName();
                                    for (ConnectedQuizClient client: allClients)
                                    {
                                        client.pw.println(activatedSet);
                                    }
                                    System.out.println("SERVER: Postaje aktivan set " + parent.getActiveSet().getSetName());
                                    break;
                                }
                            }
                        }
                        else if (clientMess.startsWith("Eject contestant"))
                        {
                            System.out.println(clientMess);
                            String[] ejectCnt = clientMess.split(":");
                            for (Contestant cnt: this.contestants)
                            {
                                if (cnt.getUserName().equals(ejectCnt[1]))
                                {
                                    this.contestants.remove(cnt);
                                    break;
                                }
                            }
                            
                            for (ConnectedQuizClient client: this.allClients)
                            {
                                System.out.println(client.getUserName());
                                if (client.getUserName().equals(ejectCnt[1]))
                                {
                                    client.setUserName("");
                                    client.setPassword("");
                                    client.setRole("");
                                    client.setClientStatus(3);
                                    client.pw.println("ContestantAdio!");
                                    System.out.println(ejectCnt[1] + " adio!");
                                    break;
                                }
                            }
                            
                            String contestantList = "Contestant ejected";
                                
                            for (Contestant cnt: this.contestants)
                                contestantList += ":" + cnt.getUserName();

                            for (ConnectedQuizClient client: allClients)
                                client.pw.println(contestantList);
                            
                            ByteArrayOutputStream bytesArray = new ByteArrayOutputStream();
                            try (FileInputStream readFile = new FileInputStream(usersTxt)) 
                            {
                                byte[] buffer = new byte[1024];
                                int bytesRead;
                                while ((bytesRead = readFile.read(buffer)) != -1) 
                                    bytesArray.write(buffer, 0, bytesRead);
                            } catch (IOException e) {
                                System.out.println("Greska prilikom citanja fajla users.txt!");
                            }
                            byte[] encryptedUsers = bytesArray.toByteArray();
                            String decryptedUsers = do_AESDecryption(encryptedUsers, symmetricKey, initializationVector);
                            
                            String[] splitedUsers = decryptedUsers.split("\n");
                            String resultUsers = "";
                            
                            for (String userString: splitedUsers)
                            {
                                String[] userInfo = userString.split(":");
                                if (!userInfo[0].equals(ejectCnt[1]))
                                    resultUsers += userString + "\n";
                            }
                            
                            encryptedUsers = do_AESEncryption(resultUsers, symmetricKey, initializationVector);
                            
                            try (FileOutputStream writer = new FileOutputStream(usersTxt)) 
                            {
                                writer.write(encryptedUsers);
                            } catch (IOException e) {
                                System.out.println("Greska prilikom upisivanja u fajl users.txt!");
                            }
                        }
                        else if (clientMess.startsWith("Eject admin"))
                        {
                            String[] ejectAdm = clientMess.split(":");
                            if (!ejectAdm[1].equals(this.userName))
                            {
                                for (String adm: this.admins)
                                {
                                    if (adm.equals(ejectAdm[1]))
                                    {
                                        this.admins.remove(adm);
                                        break;
                                    }
                                }

                                for (ConnectedQuizClient client: this.allClients)
                                {
                                    if (client.getUserName().equals(ejectAdm[1]))
                                    {
                                        client.setUserName("");
                                        client.setPassword("");
                                        client.setRole("");
                                        client.setClientStatus(3);
                                        client.pw.println("AdminAdio!");
                                        break;
                                    }
                                }

                                String adminList = "Admin ejected";

                                for (String adm: this.admins)
                                    adminList += ":" + adm;

                                for (ConnectedQuizClient client: allClients)
                                    client.pw.println(adminList);
                                
                                ByteArrayOutputStream bytesArray = new ByteArrayOutputStream();
                                try (FileInputStream readFile = new FileInputStream(usersTxt)) 
                                {
                                    byte[] buffer = new byte[1024];
                                    int bytesRead;
                                    while ((bytesRead = readFile.read(buffer)) != -1) 
                                        bytesArray.write(buffer, 0, bytesRead);
                                } catch (IOException e) {
                                    System.out.println("Greska prilikom citanja fajla users.txt!");
                                }
                                byte[] encryptedUsers = bytesArray.toByteArray();
                                String decryptedUsers = do_AESDecryption(encryptedUsers, symmetricKey, initializationVector);

                                String[] splitedUsers = decryptedUsers.split("\n");
                                String resultUsers = "";

                                for (String userString: splitedUsers)
                                {
                                    String[] userInfo = userString.split(":");
                                    if (!userInfo[0].equals(ejectAdm[1]))
                                        resultUsers += userString + "\n";
                                }

                                encryptedUsers = do_AESEncryption(resultUsers, symmetricKey, initializationVector);

                                try (FileOutputStream writer = new FileOutputStream(usersTxt)) 
                                {
                                    writer.write(encryptedUsers);
                                } catch (IOException e) {
                                    System.out.println("Greska prilikom upisivanja u fajl users.txt!");
                                }
                            }
                            else
                                this.pw.println("Ne mozete izbaciti sami sebe!");
                        }
                        else if (clientMess.equals("Logout")) 
                        {
                            this.userName = "";
                            this.password = "";
                            this.role = "";
                            this.clientStatus = 3;
                        }
                    }
                    catch (IOException ex) 
                    {
                        System.out.println("Diskonektovan korisnik!");
                        this.userName = "";
                        this.password = "";
                        this.role = "";
                        this.clientStatus = 3;
                        return;
                    } 
                    catch (Exception ex) 
                    {
                    Logger.getLogger(ConnectedQuizClient.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    break;

                case 2:
                    try 
                    {
                        String clientMess = this.br.readLine();
                        if (clientMess.startsWith("Get new set"))
                        {
                            String[] getNewSet = clientMess.split(":");
                            for(Contestant cnt: this.contestants)
                            {
                                if (getNewSet[1].equals(cnt.getUserName()))
                                {
                                    boolean exist = false;
                                    int setNumber = 0;
                                    
                                    for (ContestantSetSuccess css: cnt.getSets())
                                    {
                                        System.out.println("Takmicar ima " + css.getSet().getSetName() + ", a aktivan je " + parent.getActiveSet().getSetName());
                                        if (css.getSet().getSetName().equals(parent.getActiveSet().getSetName()))
                                        {
                                            exist = true;
                                            break;
                                        }
                                        
                                        setNumber++;
                                    }
                                    
                                    if(!exist)
                                        cnt.addSet(parent.getActiveSet());
                                    
                                    int answeredQuestions = cnt.getSets().get(setNumber).getTotalAnswers();
                                    
                                    if (exist && (answeredQuestions == 10)) // || cnt.getSets().get(setNumber).getRejected()
                                    {
                                        this.pw.println("Vec ste zavrsili sa ovim setom pitanja!");
                                    }
                                    else
                                    {
                                        String help1 = cnt.getSets().get(setNumber).getFiftyFifty()? "ima" : "nema";
                                        String help2 = cnt.getSets().get(setNumber).getChangeQuestion()? "ima" : "nema";
                                        String help3 = cnt.getSets().get(setNumber).getFriendHelp()? "ima" : "nema";
                                        
                                        this.pw.println("Let's go with set " + parent.getActiveSet().getSetName() + ":" 
                                                        + help1 + ":" + help2 + ":" + help3);
                                        
                                        clientMess = "";
                                        while(clientMess.equals(""))
                                            clientMess = this.br.readLine();
                                        
                                        //System.out.println("Takmicar je spreman!"); // za odgovaranje svojih pitanja, ne za pomoco
                                        cnt.setAvailable(false);
                                        
                                        int question;
                                        boolean firstTime = true;
                                        
                                        for (int i = answeredQuestions; i < 10; i++)
                                        {
                                            question = i;
                                            if (!cnt.getSets().get(setNumber).getChangeQuestion() && cnt.getSets().get(setNumber).getChangedQuestion() == i)
                                                question = 10;
                                            
                                            String questionText = cnt.getSets().get(setNumber).getSet().getQuestions().get(question).getQuestionText();
                                            if (firstTime)    
                                                cnt.getSets().get(setNumber).getSet().getQuestions().get(question).shuffleAnswers();
                                            firstTime = false;
                                            
                                            String answerA = cnt.getSets().get(setNumber).getSet().getQuestions().get(question).getAnswers().get(0).getAnswerText();
                                            String answerB = cnt.getSets().get(setNumber).getSet().getQuestions().get(question).getAnswers().get(1).getAnswerText();
                                            String answerC = cnt.getSets().get(setNumber).getSet().getQuestions().get(question).getAnswers().get(2).getAnswerText();
                                            String answerD = cnt.getSets().get(setNumber).getSet().getQuestions().get(question).getAnswers().get(3).getAnswerText();
                                            this.pw.println("Question:" + String.valueOf(i + 1) + ". "+ questionText + answerA + ":" + answerB + ":" + answerC + ":" + answerD);
                                            //System.out.println("Question:" + (char) (i + 1) + ". "+ questionText + ":" + answerA + ":" + answerB + ":" + answerC + ":" + answerD);
                                            if (!cnt.getSets().get(setNumber).getFiftyFifty() && cnt.getSets().get(setNumber).getEjectedQuestions().get(0) == question)
                                                this.pw.println("Eject answers:" + cnt.getSets().get(setNumber).getEjectedQuestions().get(1) + ":" + cnt.getSets().get(setNumber).getEjectedQuestions().get(2));
                                            
                                            clientMess = "";
                                            while(clientMess.equals(""))
                                                clientMess = this.br.readLine();
                                            
                                            if (clientMess.equals("fifty_fifty"))
                                            {
                                                if (!cnt.getSets().get(setNumber).getFiftyFifty())
                                                    this.pw.println("Vec ste iskoristili tu pomoc!");
                                                else 
                                                {
                                                    Random random = new Random();
                                                    int ejected1 = random.nextInt(4);
                                                    while (cnt.getSets().get(setNumber).getSet().getQuestions().get(question).getAnswers().get(ejected1).getCorrect())
                                                        ejected1 = random.nextInt(4);
                                                    int ejected2 = random.nextInt(4);
                                                    while (cnt.getSets().get(setNumber).getSet().getQuestions().get(question).getAnswers().get(ejected2).getCorrect() ||
                                                           ejected2 == ejected1)
                                                        ejected2 = random.nextInt(4);
                                                    cnt.getSets().get(setNumber).setFiftyFifty(false);
                                                    cnt.getSets().get(setNumber).addEjectedQuestions(question);
                                                    cnt.getSets().get(setNumber).addEjectedQuestions(ejected1);
                                                    cnt.getSets().get(setNumber).addEjectedQuestions(ejected2);
                                                }
                                                
                                                i--;
                                            }
                                            else if (clientMess.equals("change_question"))
                                            {
                                                if (!cnt.getSets().get(setNumber).getChangeQuestion())
                                                    this.pw.println("Vec ste iskoristili tu pomoc!");
                                                else
                                                {
                                                    this.pw.println("ChangedQuestion");
                                                    cnt.getSets().get(setNumber).setChangeQuestion(false);
                                                    cnt.getSets().get(setNumber).setChangedQuestion(question);
                                                    firstTime = true;
                                                }
                                                
                                                i--;
                                            }
                                            else if (clientMess.equals("friend_help"))
                                            {
                                                if (!cnt.getSets().get(setNumber).getFriendHelp())
                                                    this.pw.println("Vec ste iskoristili tu pomoc!");
                                                else
                                                {
                                                    String readyContestants = "AvailableContestants";
                                                    for (Contestant cont: this.contestants)
                                                    {
                                                        if (cont.getAvailable())
                                                            readyContestants += ":" + cont.getUserName();
                                                    }
                                                    if (readyContestants.equals("AvailableContestants"))
                                                        this.pw.println("HelpNotSuccessful:Trenutno nema takmicara dostupnih za pomoc!");
                                                    else
                                                    {
                                                        this.pw.println(readyContestants);
                                                        clientMess = "";
                                                        while (clientMess.equals(""))
                                                            clientMess = this.br.readLine();
                                                        if (clientMess.startsWith("Chosen friend"))
                                                        {
                                                            String chosenFriend[] = clientMess.split(":");
                                                            for (ConnectedQuizClient client: allClients)
                                                            {
                                                                if (client.getUserName().equals(chosenFriend[1]))
                                                                {
                                                                    client.pw.println("ContestantNeedsHelp:" + this.userName);
                                                                    client.pw.println("FriendQuestion:" + questionText + answerA + ":" + answerB + ":" + answerC + ":" + answerD);
                                                                    if (!cnt.getSets().get(setNumber).getFiftyFifty() && cnt.getSets().get(setNumber).getEjectedQuestions().get(0) == question)
                                                                        client.pw.println("FriendEjectAnswers:" + cnt.getSets().get(setNumber).getEjectedQuestions().get(1) + ":" + cnt.getSets().get(setNumber).getEjectedQuestions().get(2));
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        
                                                        this.pw.println("FriendAsked");
                                                        cnt.getSets().get(setNumber).setFriendHelp(false);
                                                    }
                                                }
                                                
                                                i--;
                                            }
                                            else if (clientMess.equals("setRejected"))
                                            {
                                                cnt.getSets().get(setNumber).setRejected(false);
                                                i = 10;
                                                //System.out.println("Izasao iz prozora");
                                            }
                                            else if (clientMess.equals("SendResults!"))
                                            {
                                                String message = "Results:";
                                                Collections.sort(contestants);
                                                for(int j = 0; j < contestants.size(); j++)
                                                {
                                                    message += String.valueOf(j+1) + ". " + contestants.get(j).getUserName() + " " + contestants.get(j).getCorrectAnswers() + "/" + contestants.get(j).getTotalAnswers() + ":";
                                                }
                                                //System.out.println(message);
                                                this.pw.println(message);
                                                i--;
                                            }
                                            else if (clientMess.equals("Logout"))
                                            {
                                                for(Contestant cntst: this.contestants)
                                                {
                                                    if (cntst.getUserName().equals(this.userName))
                                                    {
                                                        cntst.setAvailable(false);
                                                        break;
                                                    }
                                                }
                                                
                                                this.userName = "";
                                                this.password = "";
                                                this.role = "";
                                                this.clientStatus = 3;
                                                i = 10;
                                            }
                                            else if (!clientMess.equals(""))
                                            {
                                                int cntAnswer = Integer.parseInt(clientMess);
                                                System.out.print("Korisnikov odgovor " + clientMess);
                                                cnt.getSets().get(setNumber).addTotalAnswers();
                                                if (cnt.getSets().get(setNumber).getSet().getQuestions().get(question).getAnswers().get(cntAnswer).getCorrect())
                                                {
                                                    cnt.getSets().get(setNumber).addCorrectAnswers();
                                                    System.out.println(" je tacan.");
                                                }
                                                else
                                                    System.out.println(" je netacan.");

                                                cnt.scoreUpdate();
                                                System.out.println("Trenutno stanje: " + cnt.getCorrectAnswers() + "/" + cnt.getTotalAnswers());
                                                firstTime = true;
                                            }
                                        }
                                        //System.out.println("Takmicar je zavrsio set!");
                                        cnt.setAvailable(true);
                                        
                                        this.pw.println("SetEnd!");
                                    }
                                }
                            }
                        }
                        else if (clientMess.equals("SendResults!"))
                        {
                            String message = "Results:";
                            Collections.sort(contestants);
                            for(int i = 0; i < contestants.size(); i++)
                            {
                                message += String.valueOf(i+1) + ". " + contestants.get(i).getUserName() + " " + contestants.get(i).getCorrectAnswers() + "/" + contestants.get(i).getTotalAnswers() + ":";
                            }
                            //System.out.println(message);
                            this.pw.println(message);
                        }
                        else if (clientMess.startsWith("FriendAnswer"))
                        {
                            String[] friendAnswer = clientMess.split(":");
                            
                            for (ConnectedQuizClient client: allClients)
                            {
                                if (client.getUserName().equals(friendAnswer[2]))
                                {
                                    client.pw.println("FriendSentHelp:" + friendAnswer[1] + ":" + friendAnswer[3]);
                                    break;
                                }
                            }
                        }
                        else if (clientMess.equals("Logout")) 
                        {
                            for(Contestant cnt: this.contestants)
                            {
                                if (cnt.getUserName().equals(this.userName))
                                {
                                    cnt.setAvailable(false);
                                    break;
                                }
                            }
                            
                            this.userName = "";
                            this.password = "";
                            this.role = "";
                            this.clientStatus = 3;
                            
                            for(ConnectedQuizClient client: this.allClients)
                            {
                                System.out.println(client.getUserName());
                            }
                        }
                    }
                    catch (IOException ex) 
                    {
                        System.out.println("Diskonektovan korisnik!");
                        for(Contestant cnt: this.contestants)
                        {
                            if (cnt.getUserName().equals(this.userName))
                            {
                                cnt.setAvailable(false);
                                break;
                            }
                        }

                        this.userName = "";
                        this.password = "";
                        this.role = "";
                        this.clientStatus = 3;
                        
                        return;
                    }
                    break;
                default:
                    break;
            }
        }
    }
    
    public static byte[] do_AESEncryption(String plainText, SecretKey secretKey, byte[] initializationVector) throws Exception
    {
        Cipher cipher = Cipher.getInstance(AES_CIPHER_ALGORITHM);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(initializationVector);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivParameterSpec);
        return cipher.doFinal(plainText.getBytes());
    }

    public static String do_AESDecryption(byte[] cipherText, SecretKey secretKey, byte[] initializationVector) throws Exception
    {
        Cipher cipher = Cipher.getInstance(AES_CIPHER_ALGORITHM);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(initializationVector);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivParameterSpec);
        byte[] result = cipher.doFinal(cipherText);
        return new String(result);
    }
}
