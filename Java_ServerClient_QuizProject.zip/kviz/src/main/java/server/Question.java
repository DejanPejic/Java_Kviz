package server;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author Dejan Pejic
 */
public class Question implements Serializable
{
    private String questionText;
    private ArrayList<Answer> answers = new ArrayList();

    public String getQuestionText() 
    {
        return questionText;
    }
    
    public void setQuestionText(String questionText)
    {
        this.questionText = questionText;
    }

    public ArrayList<Answer> getAnswers() 
    {
        return answers;
    }
    
    public void setAnswers(ArrayList<Answer> answers)
    {
        this.answers = answers;
    }
    
    public void addAnswer(Answer answer) 
    {
        this.answers.add(answer);
    }
    
    public void shuffleAnswers()
    {
        Collections.shuffle(this.answers);
    }
}
 
