package server;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

/**
 *
 * @author Dejan Pejić
 */
public class QuizServer
{
    private ServerSocket ssocket;
    private int port;
    private ArrayList<ConnectedQuizClient> clients;
    private ArrayList<Contestant> contestants;
    private ArrayList<Set> sets;
    private ArrayList<String> admins;
    private Set activeSet;
    private SecretKey symmetricKey;
    private byte[] initializationVector;
    
    ObjectInputStream inputStreamContestants;
    
    private final String contestantsTxt = "C:\\Users\\Korisnik\\Desktop\\Java-zadatak2\\contestants.txt";
    private final String adminsTxt = "C:\\Users\\Korisnik\\Desktop\\Java-zadatak2\\admins.txt";
    private final String usersTxt = "C:\\Users\\Korisnik\\Desktop\\Java-zadatak2\\users.txt";
    private final String setTxt = "C:\\Users\\Korisnik\\Desktop\\Java-zadatak2\\set";
    private static final String AES_CIPHER_ALGORITHM = "AES/CBC/PKCS5PADDING";
    private static final String AES = "AES";
    
    public ServerSocket getSsocket() 
    {
        return ssocket;
    }
    
    public void setSsocket(ServerSocket ssocket) 
    {
        this.ssocket = ssocket;
    }

    public int getPort() 
    {
        return port;
    }

    public void setPort(int port) 
    {
        this.port = port;
    }
    
    public void setActiveSet(Set set)
    {
        this.activeSet = set;
    }
    
    public Set getActiveSet()
    {
        return activeSet;
    }
    
    public void acceptClients() throws Exception 
    {
        Socket client = null;
        Thread thr;
        
        Thread thrTerm;
        ProgramTerminate termServer = new ProgramTerminate(contestants, admins);
        thrTerm = new Thread(termServer);
        thrTerm.start();
        
        while (true) 
        {
            try {
                System.out.println("Waiting for new clients..");
                client = this.ssocket.accept();
            } catch (IOException ex) {
                Logger.getLogger(QuizServer.class.getName()).log(Level.SEVERE, null, ex);
            }
            if (client != null) 
            {
                ConnectedQuizClient clnt = new ConnectedQuizClient(client, clients, contestants, sets, admins, this, symmetricKey, initializationVector);
                clients.add(clnt);
                thr = new Thread(clnt);
                thr.start();
            }
        }
    }
    
    public QuizServer(int port) throws Exception 
    {
        this.clients = new ArrayList<>();
        this.contestants = new ArrayList<>();
        this.sets = new ArrayList<>();
        this.admins = new ArrayList<>();
        this.symmetricKey = createAESKey();
        this.initializationVector = createInitializationVector();
      
        String adminLine;
            
        try (BufferedReader br = new BufferedReader(new FileReader(adminsTxt))) 
        {
            while ((adminLine = br.readLine()) != null) 
            {
                if(!adminLine.isEmpty())
                    admins.add(adminLine);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        try 
        {
            this.port = port;
            this.ssocket = new ServerSocket(port);
        } catch (IOException ex) {
            Logger.getLogger(QuizServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        // load contestants
        try 
        {
            inputStreamContestants = new ObjectInputStream(new FileInputStream(contestantsTxt));
            ArrayList<Contestant> loadedContestants = new ArrayList<>();
            loadedContestants=(ArrayList<Contestant>) inputStreamContestants.readObject();
            this.contestants = loadedContestants;
            inputStreamContestants.close();
        } catch (IOException ex) {
            Logger.getLogger(ConnectedQuizClient.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConnectedQuizClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String finalSetTxt;
        String line, trimLine;
        Pattern questionPattern = Pattern.compile("^(?:1[0-1]|[1-9])\\..*$");
        Pattern answerPattern = Pattern.compile("^[a-d]\\)\\s*(.*)$");
        Matcher questionMatcher;
        Matcher answerMatcher;
        int keyIndex;
        Question question = new Question();
        
        // load Sets of Questions
        for (int i = 1; i <= 4; i++)
        {
            Set set = new Set();
            set.setSetName("Set" + i);
            finalSetTxt = setTxt + i + ".txt";
            //System.out.println(finalSetTxt);
            try (BufferedReader br = new BufferedReader(new FileReader(finalSetTxt))) 
            {
                while ((line = br.readLine()) != null) 
                {
                    trimLine = line.trim();
                    //System.out.println(trimLine);
                    if(!trimLine.isEmpty())
                    {
                        questionMatcher = questionPattern.matcher(trimLine);
                        answerMatcher = answerPattern.matcher(trimLine);
                        
                        if(questionMatcher.find())
                        {
                            question = new Question();
                            keyIndex = trimLine.indexOf('.');
                            question.setQuestionText(trimLine.substring(keyIndex + 2).trim());
                        }
                        else if(answerMatcher.find())
                        {
                            Answer answer = new Answer();
                            keyIndex = trimLine.indexOf(')');
                            answer.setAnswerText(trimLine.substring(keyIndex + 2).trim());
                            if (trimLine.charAt(0) == 'd')
                                answer.setCorrect(true);
                            else
                                answer.setCorrect(false);
                            
                            question.addAnswer(answer);
                            
                            if (trimLine.charAt(0) == 'd')
                                set.addQuestion(question);
                        }
                    }
                }
                
                sets.add(set);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
        this.activeSet = sets.get(0);
        
        if (contestants.isEmpty() && admins.size() == 1)
        {
            String initialAdmin = "admin:admin:admin\n";
            byte[] encryptedInitialAdmin = do_AESEncryption(initialAdmin, symmetricKey, initializationVector);
            try (FileOutputStream writer = new FileOutputStream(usersTxt)) 
            {
                writer.write(encryptedInitialAdmin);
            } catch (IOException e) {
                System.out.println("Greska!");
            }
        }
    }
    
    public static SecretKey createAESKey() throws Exception 
    {
        String seed = "RSZEOS2024";
        SecureRandom secureRandom = new SecureRandom();
        secureRandom.setSeed(seed.getBytes());
        KeyGenerator keygenerator = KeyGenerator.getInstance(AES);
        keygenerator.init(128, secureRandom);
        SecretKey key = keygenerator.generateKey();
        return key;
    }
  
    public static byte[] createInitializationVector()
    {
        byte[] initializationVector = new byte[16];
        String seed = "RSZEOS2024";
        SecureRandom secureRandom = new SecureRandom();
        secureRandom.setSeed(seed.getBytes());
        secureRandom.nextBytes(initializationVector);
        return initializationVector;
    }
    
    public static byte[] do_AESEncryption(String plainText, SecretKey secretKey, byte[] initializationVector) throws Exception
    {
        Cipher cipher = Cipher.getInstance(AES_CIPHER_ALGORITHM);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(initializationVector);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivParameterSpec);
        return cipher.doFinal(plainText.getBytes());
    }

    public static void main(String[] args) throws Exception 
    {
        QuizServer server = new QuizServer(6001);

        System.out.println("Server pokrenut, slusam na portu 6001");
        System.out.println("Unesite \"Exit\" kako biste terminirali program.");
        
        server.acceptClients();
    }
}