package server;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Dejan Pejić
 */
public class ProgramTerminate implements Runnable
{
    private ArrayList<Contestant> contestants;
    private ArrayList<String> admins;
    ObjectOutputStream outContestants;
    private String contestantsTxt = "C:\\Users\\Korisnik\\Desktop\\Java-zadatak2\\contestants.txt";
    private String adminsTxt = "C:\\Users\\Korisnik\\Desktop\\Java-zadatak2\\admins.txt";
    
    public ProgramTerminate(ArrayList<Contestant> contestants, ArrayList<String> admins) 
    {
        this.contestants = contestants;
        this.admins = admins;
    }
    
    @Override
    public void run() 
    {
        Scanner sc = new Scanner(System.in);
        while(true) 
        {
            String userMess = sc.nextLine();
            if (userMess.equalsIgnoreCase("Terminate")) {
                System.out.println("Program je zavrsio sa radom.");
                saveContestants();
                saveAdmins();
                System.exit(0);
            }
            else 
            {
                System.out.println("Dozvoljena komanda: Terminate");
            }
        }
    }
    
    void saveContestants() 
    {
        try 
        {
            outContestants = new ObjectOutputStream(new FileOutputStream(contestantsTxt));
            outContestants.writeObject(this.contestants);
            outContestants.close();
        } catch (FileNotFoundException ex1) {
            Logger.getLogger(ConnectedQuizClient.class.getName()).log(Level.SEVERE, null, ex1);
        } catch (IOException ex1) {
            Logger.getLogger(ConnectedQuizClient.class.getName()).log(Level.SEVERE, null, ex1);
        }
        System.out.println("Takmicari sacuvani.");
    }
    
    void saveAdmins()
    {
        String admLine;
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(adminsTxt))) {
            for (String admStr: this.admins)
            {
                admLine = admStr + "\n";
                writer.write(admLine);
            }
        } catch (IOException e) {
            System.out.println("Greska prilikom cuvanja admin fajla!");
        }
        System.out.println("Admini sacuvani.");
    }
}
