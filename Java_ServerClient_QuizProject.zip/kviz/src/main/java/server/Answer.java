package server;

import java.io.Serializable;

/**
 *
 * @author Dejan Pejic
 */
public class Answer  implements Serializable
{
    private String answerText;
    private boolean correct;

    public String getAnswerText()
    {
            return answerText;
    }
    
    public void setAnswerText(String answerText)
    {
        this.answerText = answerText;
    }
    
    public boolean getCorrect()
    {
            return correct;
    }
    
    public void setCorrect(boolean correct)
    {
        this.correct = correct;
    }
}
