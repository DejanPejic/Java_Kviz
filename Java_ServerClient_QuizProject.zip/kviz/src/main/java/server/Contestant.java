package server;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Dejan Pejić
 */
public class Contestant implements Serializable, Comparable<Contestant>
{
    private String userName;
    private ArrayList<ContestantSetSuccess> sets;
    private int totalAnswers;
    private int correctAnswers;
    private boolean active;
    private boolean available;
    
    public Contestant(String userName)
    {
        this.userName = userName;
        this.sets = new ArrayList<>(); 
        this.totalAnswers = 0;
        this.correctAnswers = 0;
        this.active = false;
        this.available = false;
    }
    
    public ArrayList<ContestantSetSuccess> getSets()
    {
        return sets;
    }
    
    public void setSets(ArrayList<ContestantSetSuccess> sets)
    {
        this.sets = sets;
    }
    
    public String getUserName()
    {
        return userName;
    }
    
    public void setUserName(String userName)
    {
        this.userName = userName;
    }
    
    public void addSet(Set set)
    {
        sets.add(new ContestantSetSuccess(set));
    }
    
    public void scoreUpdate()
    {
        int totalNumber = 0;
        int correctNumber = 0;
        
        for (ContestantSetSuccess set: sets)
        {
            totalNumber += set.getTotalAnswers();
            correctNumber += set.getCorrectAnswers();
        }
        
        totalAnswers = totalNumber;
        correctAnswers = correctNumber;
    }
    
    public int getTotalAnswers()
    {
        return totalAnswers;
    }
    
    public int getCorrectAnswers()
    {
        return correctAnswers;
    }
    
    public boolean getAvailable()
    {
        return available;
    }
    
    public void setAvailable(boolean available)
    {
        this.available = available;
    }
    
    @Override
    public int compareTo(Contestant cnt) 
    {
        return Integer.compare(cnt.correctAnswers, this.correctAnswers);
    }
}
